/* 每日单词 v1.2 · 多词库 / 拼写 / 遮词 / 生词本学习 / 串联阅读 */
const ALL_BOARDS = [
  { k: 'cet4', n: '四级' },
  { k: 'cet6', n: '六级' },
  { k: 'kaoyan', n: '考研' },
  { k: 'ielts', n: '雅思' },
  { k: 'toefl', n: '托福' },
];
const INLINE_ALL = window.__ALL_BOARDS__ || null;
const BOARDS = INLINE_ALL ? ALL_BOARDS
  : (window.__WORDS__ ? [{ k: window.__BOARD_KEY__ || 'cet4', n: window.__BOARD_NAME__ || '词库' }] : ALL_BOARDS);
function storageOK() {
  try { localStorage.setItem('__probe__', '1'); localStorage.removeItem('__probe__'); return true; }
  catch (e) { return false; }
}
const INTERVALS = [1, 3, 7, 15, 30];
const GROUP_SIZE = 25;

const $ = (s) => document.querySelector(s);
const el = (tag, cls, html) => {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html != null) e.innerHTML = html;
  return e;
};

const S = {
  hasChrome: typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local,
  async get(key, def) {
    if (S.hasChrome) {
      const o = await chrome.storage.local.get(key);
      return o[key] === undefined ? def : o[key];
    }
    try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : def; } catch (e) { return def; }
  },
  async set(key, val) {
    if (S.hasChrome) return chrome.storage.local.set({ [key]: val });
    try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) {}
  },
};

function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
function diffDays(a, b) {
  return Math.round((new Date(b + 'T00:00:00') - new Date(a + 'T00:00:00')) / 86400000);
}

let STATE = { active: 'cet4', boards: {} };
let DATA = null;
let cache = window.__WORDS__ ? { [BOARDS[0].k]: { words: window.__WORDS__ } } : {};
let rate = 0.8;
let voice = null;

function board(k) { return BOARDS.find((b) => b.k === k) || BOARDS[0]; }
function curState() {
  if (!STATE.boards[STATE.active]) {
    STATE.boards[STATE.active] = { start: todayStr(), pace: 100, words: {}, days: {}, spell: {} };
  }
  const s = STATE.boards[STATE.active];
  if (!s.spell) s.spell = {};
  return s;
}
function totalDays() { return Math.max(1, Math.ceil(DATA.words.length / curState().pace)); }
function dayIndex() {
  const s = curState();
  return Math.max(1, Math.min(totalDays(), diffDays(s.start, todayStr()) + 1));
}
function dayWords() {
  const s = curState();
  const start = (dayIndex() - 1) * s.pace;
  return DATA.words.slice(start, start + s.pace);
}
function statusOf(w) { const r = curState().words[w]; return r ? r.s : 0; }
function setStatus(w, s) {
  const st = curState();
  if (s === 0) delete st.words[w];
  else if (s === 1) st.words[w] = { s: 1, n: 0, c: 0 };
  else st.words[w] = { s: 2, n: Date.now() + 86400000, c: 0 };
  const t = todayStr();
  st.days[t] = Math.max(st.days[t] || 0, 1);
  save();
}
async function save() { await S.set('state', STATE); }
function countDone(words) { return words.filter((x) => statusOf(x.w) !== 0).length; }
function streak() {
  const st = curState();
  let n = 0;
  const d = new Date();
  for (;;) {
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    if (!st.days[key]) break;
    n++; d.setDate(d.getDate() - 1);
  }
  return n;
}

/* ---------- 语音 ---------- */
function pickVoice() {
  const vs = (speechSynthesis.getVoices() || []).filter((v) => /^en/i.test(v.lang));
  if (!vs.length) return null;
  return vs.find((v) => /natural/i.test(v.name) && /en-US/i.test(v.lang)) ||
    vs.find((v) => /en-US/i.test(v.lang) && /microsoft/i.test(v.name)) ||
    vs.find((v) => /en-US/i.test(v.lang)) || vs[0];
}
function speak(text, cb) {
  try {
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = 'en-US'; u.rate = rate;
    if (voice) u.voice = voice;
    u.onend = () => cb && cb();
    speechSynthesis.speak(u);
  } catch (e) { toast('当前浏览器不支持语音合成'); }
}
function playList(list) {
  const queue = list.slice();
  const step = () => {
    if (!queue.length) return;
    speak(queue.shift(), () => setTimeout(step, 700));
  };
  step();
}

/* ---------- 通用渲染 ---------- */
function renderBoards() {
  const box = $('#boards');
  box.innerHTML = '';
  if (BOARDS.length < 2) { box.style.display = 'none'; return; }
  BOARDS.forEach((b) => {
    const s = STATE.boards[b.k];
    const known = s ? Object.values(s.words).filter((x) => x.s === 1).length : 0;
    const btn = el('button', b.k === STATE.active ? 'chip on' : 'chip', `${b.n}<small>${known}</small>`);
    btn.onclick = async () => { STATE.active = b.k; await save(); await refresh(); };
    box.appendChild(btn);
  });
}

function renderStats() {
  $('#stDay').textContent = `Day ${dayIndex()}`;
  $('#stTotal').textContent = `/ ${totalDays()} 天`;
  $('#stDone').textContent = countDone(dayWords());
  $('#stPace').textContent = `/ ${curState().pace} 今日`;
  $('#stStreak').textContent = streak();
  $('#nReview').textContent = dueWords().length;
  $('#nBook').textContent = DATA.words.filter((x) => statusOf(x.w) === 2).length;
  document.querySelectorAll('#pace button').forEach((b) => b.classList.toggle('on', Number(b.dataset.p) === curState().pace));
}

/* ---------- 今日 ---------- */
function renderToday() {
  const box = $('#groups');
  box.innerHTML = '';
  const words = dayWords();
  const groups = [];
  for (let i = 0; i < words.length; i += GROUP_SIZE) groups.push(words.slice(i, i + GROUP_SIZE));
  groups.forEach((list, gi) => {
    const g = el('div', 'group');
    const done = countDone(list);
    const head = el('div', 'ghead');
    head.appendChild(el('h2', null, `第 ${gi + 1} 组 · ${list.length} 词`));
    head.appendChild(el('div', 'bar', `<i style="width:${(done / list.length) * 100}%"></i>`));
    head.appendChild(el('div', 'pct', `${done}/${list.length}`));
    const pb = el('button', 'ghost', '▶ 连读');
    pb.onclick = () => playList(list.map((x) => x.w));
    head.appendChild(pb);
    g.appendChild(head);
    list.forEach((item) => {
      const row = el('div', 'word');
      const st = statusOf(item.w);
      if (st === 1) row.classList.add('known');
      if (st === 2) row.classList.add('unknown');
      const spk = el('button', 'spk', '🔊');
      spk.onclick = () => speak(item.w);
      const w = el('div', 'w', item.w);
      w.onclick = () => speak(item.w);
      const p = el('div', 'p', item.p ? `/${item.p}/` : '');
      const m = el('div', 'm', item.m);
      const act = el('div', 'act');
      const ok = el('button', 'ok', '✓');
      ok.onclick = () => { setStatus(item.w, 1); renderAll(); };
      const no = el('button', 'no', '✗');
      no.onclick = () => { setStatus(item.w, 2); renderAll(); toast('已加入复习与生词本'); };
      act.append(ok, no);
      row.append(spk, w, p, m, act);
      g.appendChild(row);
    });
    box.appendChild(g);
  });
}

/* ---------- 拼写 ---------- */
let spellIdx = 0;
let spellMsg = null;
let spellInputValue = '';

function spellQueue() { return dayWords().filter((x) => !curState().spell[x.w]); }

function renderSpell() {
  const box = $('#spellCard');
  const q = spellQueue();
  const total = dayWords().length;
  const done = total - q.length;
  if (!q.length) {
    box.innerHTML = `<div class="empty">今天的 ${total} 个词全部拼写通过 ✅<br><span class="hint">明天会按新一天刷新；也可先去做“复习”。</span></div>`;
    return;
  }
  if (spellIdx >= q.length) spellIdx = 0;
  const item = q[spellIdx];
  box.innerHTML = '';
  const card = el('div', 'card');
  card.appendChild(el('div', 'hint', `拼写 ${done + 1} / ${total} · 听到/看到中文，写出单词`));
  card.appendChild(el('div', 'mean', item.m));
  card.appendChild(el('div', 'ipa', item.p ? `/${item.p}/` : ''));
  const row = el('div', 'spellRow');
  const inp = document.createElement('input');
  inp.type = 'text'; inp.autocapitalize = 'off'; inp.autocomplete = 'off'; inp.spellcheck = false;
  inp.placeholder = '输入单词，回车提交';
  inp.value = spellInputValue;
  inp.oninput = () => { spellInputValue = inp.value; };
  const snd = el('button', 'ghost', '🔊 听发音');
  snd.onclick = () => speak(item.w);
  row.append(inp, snd);
  card.appendChild(row);
  if (spellMsg) card.appendChild(el('div', spellMsg.ok ? 'msg ok' : 'msg bad', spellMsg.text));
  const acts = el('div', 'acts');
  const sub = el('button', 'pri', '提交');
  const hint = el('button', 'ghost', '看答案');
  const check = () => {
    const v = inp.value.trim().toLowerCase();
    if (!v) return;
    if (v === item.w.toLowerCase()) {
      curState().spell[item.w] = 1;
      if (statusOf(item.w) === 2) curState().words[item.w] = { s: 2, n: Date.now() + 3 * 86400000, c: 1 };
      save();
      spellMsg = { ok: true, text: `正确：${item.w}` };
      spellInputValue = '';
      setTimeout(() => { spellMsg = null; spellIdx++; renderSpell(); renderStats(); }, 500);
      speak(item.w);
      renderStats();
      inp.value = '';
    } else {
      spellMsg = { ok: false, text: `再试一次：你写的是 “${v}”` };
      renderSpell();
      const i2 = $('#spellCard input'); if (i2) { i2.value = v; i2.focus(); }
    }
  };
  sub.onclick = check;
  inp.onkeydown = (e) => { if (e.key === 'Enter') check(); };
  hint.onclick = () => {
    spellMsg = { ok: false, text: `答案：${item.w}` };
    curState().spell[item.w] = 0;
    renderSpell();
  };
  acts.append(sub, hint);
  card.appendChild(acts);
  box.appendChild(card);
  setTimeout(() => inp.focus(), 30);
}

/* ---------- 遮住单词 ---------- */
let hideIdx = 0;
let hideRevealed = false;

function renderHide() {
  const box = $('#hideCard');
  const words = dayWords();
  if (hideIdx >= words.length) hideIdx = 0;
  const item = words[hideIdx];
  box.innerHTML = '';
  const card = el('div', 'card');
  card.appendChild(el('div', 'hint', `遮住单词 ${hideIdx + 1} / ${words.length} · 看中文回想英文`));
  card.appendChild(el('div', 'mean', item.m));
  card.appendChild(el('div', 'ipa', item.p ? `/${item.p}/` : ''));
  const masked = el('div', 'big masked', hideRevealed ? item.w : '•'.repeat(Math.max(4, Math.min(12, item.w.length))));
  masked.onclick = () => { hideRevealed = !hideRevealed; renderHide(); };
  card.appendChild(masked);
  const acts = el('div', 'acts');
  const snd = el('button', 'ghost', '🔊 听');
  snd.onclick = () => speak(item.w);
  const show = el('button', 'ghost', hideRevealed ? '遮住' : '显示单词');
  show.onclick = () => { hideRevealed = !hideRevealed; renderHide(); };
  const ok = el('button', 'pri', '✓ 认识');
  ok.onclick = () => { setStatus(item.w, 1); hideIdx++; hideRevealed = false; renderHide(); renderStats(); };
  const no = el('button', 'ghost', '✗ 不会');
  no.onclick = () => { setStatus(item.w, 2); hideIdx++; hideRevealed = false; renderHide(); renderStats(); toast('已加入复习'); };
  acts.append(snd, show, ok, no);
  card.appendChild(acts);
  box.appendChild(card);
}

/* ---------- 生词本学习 ---------- */
let bookPhase = 'flash'; // flash | spell
let bookIdx = 0;
let bookMsg = null;

function renderBookStudy() {
  const box = $('#bookStudy');
  const list = bookList();
  if (!list.length) {
    box.innerHTML = '<div class="empty">生词本还是空的：在“今日”或“遮词”里点 ✗ 收词。</div>';
    return;
  }
  if (bookIdx >= list.length) {
    if (bookPhase === 'flash') { bookPhase = 'spell'; bookIdx = 0; }
    else { box.innerHTML = '<div class="empty">这一轮生词本学完了 ✅<br><span class="hint">点“再来一轮”可继续巩固。</span></div>'; return; }
  }
  const item = list[bookIdx];
  box.innerHTML = '';
  const card = el('div', 'card');
  if (bookPhase === 'flash') {
    card.appendChild(el('div', 'hint', `二次学习 ${bookIdx + 1} / ${list.length} · 先看一遍词形与释义`));
    card.appendChild(el('div', 'big', item.w));
    card.appendChild(el('div', 'ipa', item.p ? `/${item.p}/` : ''));
    card.appendChild(el('div', 'mean', item.m));
    const acts = el('div', 'acts');
    const snd = el('button', 'ghost', '🔊 听');
    snd.onclick = () => speak(item.w);
    const next = el('button', 'pri', '下一个');
    next.onclick = () => { bookIdx++; renderBookStudy(); };
    acts.append(snd, next);
    card.appendChild(acts);
  } else {
    card.appendChild(el('div', 'hint', `生词拼写 ${bookIdx + 1} / ${list.length}`));
    card.appendChild(el('div', 'mean', item.m));
    const row = el('div', 'spellRow');
    const inp = document.createElement('input');
    inp.type = 'text'; inp.placeholder = '拼出这个单词'; inp.autocapitalize = 'off'; inp.spellcheck = false;
    const snd = el('button', 'ghost', '🔊');
    snd.onclick = () => speak(item.w);
    row.append(inp, snd);
    card.appendChild(row);
    if (bookMsg) card.appendChild(el('div', bookMsg.ok ? 'msg ok' : 'msg bad', bookMsg.text));
    const acts = el('div', 'acts');
    const sub = el('button', 'pri', '提交');
    sub.onclick = () => {
      const v = inp.value.trim().toLowerCase();
      if (!v) return;
      if (v === item.w.toLowerCase()) {
        const r = curState().words[item.w] || { c: 0 };
        const c = Math.min((r.c || 0) + 1, INTERVALS.length - 1);
        curState().words[item.w] = { s: 2, n: Date.now() + INTERVALS[c] * 86400000, c };
        curState().spell[item.w] = 1;
        save(); bookMsg = null; bookIdx++; renderBookStudy(); renderStats();
      } else {
        bookMsg = { ok: false, text: '没拼对，再想想（答案上一张有）' };
        renderBookStudy();
        const i2 = $('#bookStudy input'); if (i2) { i2.value = v; i2.focus(); }
      }
    };
    inp.onkeydown = (e) => { if (e.key === 'Enter') sub.click(); };
    const skip = el('button', 'ghost', '看答案');
    skip.onclick = () => { bookMsg = { ok: false, text: `答案：${item.w}` }; renderBookStudy(); };
    acts.append(sub, skip);
    card.appendChild(acts);
    setTimeout(() => inp.focus(), 30);
  }
  box.appendChild(card);
}

/* ---------- 复习 ---------- */
let reviewQueue = [];
let reviewIdx = 0;
let reveal = false;

function dueWords() {
  const now = Date.now();
  return DATA.words.filter((x) => { const r = curState().words[x.w]; return r && r.s === 2 && r.n <= now; });
}
function renderReview() {
  const box = $('#reviewCard');
  if (!box || $('#tab-review').hidden) return;
  reviewQueue = dueWords();
  if (!reviewQueue.length) { box.innerHTML = '<div class="empty">这个词库今天没有到期复习的词。</div>'; return; }
  if (reviewIdx >= reviewQueue.length) reviewIdx = 0;
  const item = reviewQueue[reviewIdx];
  box.innerHTML = '';
  const card = el('div', 'card');
  card.appendChild(el('div', 'big', item.w));
  card.appendChild(el('div', 'ipa', item.p ? `/${item.p}/` : ''));
  card.appendChild(el('div', 'mean', reveal ? item.m : '（先回想，再点“显示释义”）'));
  const acts = el('div', 'acts');
  const b1 = el('button', 'ghost', reveal ? '🔊 再听一次' : '显示释义');
  b1.onclick = () => { if (reveal) return speak(item.w); reveal = true; renderReview(); };
  const b2 = el('button', 'ghost', '忘了');
  b2.onclick = () => { curState().words[item.w] = { s: 2, n: Date.now() + 86400000, c: 0 }; save(); reveal = false; reviewIdx++; renderAll(); };
  const b3 = el('button', 'pri', '想起来了');
  b3.onclick = () => {
    const r = curState().words[item.w] || { c: 0 };
    const c = Math.min((r.c || 0) + 1, INTERVALS.length - 1);
    curState().words[item.w] = { s: 2, n: Date.now() + INTERVALS[c] * 86400000, c };
    save(); reveal = false; reviewIdx++; renderAll();
  };
  acts.append(b1, b2, b3);
  card.appendChild(acts);
  card.appendChild(el('div', 'hint', `剩余 ${reviewQueue.length - reviewIdx} / ${reviewQueue.length}`));
  box.appendChild(card);
}

/* ---------- 生词本列表 ---------- */
function bookList() { return DATA.words.filter((x) => statusOf(x.w) === 2); }
let listCollapsed = false;
function renderBook() {
  const box = $('#bookList');
  const list = bookList();
  $('#bookHint').textContent = `共 ${list.length} 词`;
  const cnt = $('#listCount'); if (cnt) cnt.textContent = list.length;
  const arrow = $('#listArrow'); if (arrow) arrow.textContent = listCollapsed ? '▸' : '▾';
  box.hidden = listCollapsed;
  box.innerHTML = '';
  if (!list.length) { box.innerHTML = '<div class="empty">还没有生词。在“今日学习”里点 ✗ 就会收进来。</div>'; return; }
  list.forEach((item) => {
    const d = el('div', 'item');
    d.innerHTML = `<b>${item.w}</b><span class="p">${item.p ? '/' + item.p + '/' : ''}</span><div class="m">${item.m}</div>`;
    box.appendChild(d);
  });
}

function renderAll() {
  renderBoards(); renderStats(); renderToday(); renderSpell(); renderHide(); renderReview(); renderBook();
  if (!$('#tab-book').hidden) renderBookStudy();
  if (!$('#tab-read').hidden) renderArticle();
  if (!$('#tab-shuffle').hidden) renderShuffle();
}

/* ---------- 导出 ---------- */
function download(name, text, type) {
  const blob = new Blob([text], { type: type || 'text/plain;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}
function exportCsv() {
  const list = bookList();
  if (!list.length) return toast('生词本是空的');
  const rows = [['word', 'ipa', 'meaning']].concat(list.map((x) => [x.w, x.p, x.m]));
  const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
  download(`${board(STATE.active).n}-生词本.csv`, '\ufeff' + csv, 'text/csv;charset=utf-8');
  toast('已导出 CSV');
}
function exportAnki() {
  const list = bookList();
  if (!list.length) return toast('生词本是空的');
  download(`${board(STATE.active).n}-生词本-anki.txt`, list.map((x) => `${x.w}\t${x.m}\t${board(STATE.active).n}`).join('\n'));
  toast('已导出，可导入 Anki');
}

let toastTimer = null;
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('on');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('on'), 1800);
}

function switchTab(name) {
  document.querySelectorAll('nav.tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === name));
  ['today', 'spell', 'hide', 'shuffle', 'book', 'read', 'review', 'settings'].forEach((k) => {
    const sec = document.getElementById('tab-' + k);
    if (sec) sec.hidden = k !== name;
  });
  if (name === 'review') { reveal = false; reviewIdx = 0; renderReview(); }
  if (name === 'book') { renderBook(); renderBookStudy(); }
  if (name === 'spell') { spellMsg = null; renderSpell(); }
  if (name === 'hide') { hideRevealed = false; renderHide(); }
  if (name === 'read') { renderArticle(); }
  if (name === 'shuffle') { shuffleDay = 0; renderShuffle(); }
}

async function loadBoard(k) {
  if (INLINE_ALL) { cache[k] = cache[k] || { words: INLINE_ALL[k] || [] }; return cache[k]; }
  if (!cache[k]) {
    const res = await fetch(`data/boards/${k}.json`);
    cache[k] = await res.json();
  }
  return cache[k];
}

async function refresh() {
  DATA = await loadBoard(STATE.active);
  if (!ARTICLES.length) {
    if (window.__ARTICLES__) ARTICLES = window.__ARTICLES__;
    else {
      try { const r = await fetch('data/articles.json'); ARTICLES = (await r.json()).articles || []; }
      catch (e) { ARTICLES = []; }
    }
  }
  curState();
  renderAll();
  const sd = $('#startDate'); if (sd) sd.value = curState().start;
}

async function boot() {
  const saved = await S.get('state', null);
  if (saved && saved.boards) STATE = saved;
  else if (saved && saved.start) {
    STATE = { active: 'cet4', boards: { cet4: { start: saved.start, pace: 100, words: saved.words || {}, days: saved.days || {}, spell: {} } } };
  }
  if (!STATE.active || !BOARDS.some((b) => b.k === STATE.active)) STATE.active = BOARDS[0].k;

  voice = pickVoice();
  speechSynthesis.onvoiceschanged = () => { voice = voice || pickVoice(); };

  const r = $('#rate');
  if (r) {
    r.value = rate;
    r.oninput = (e) => { rate = parseFloat(e.target.value); const v = $('#rateVal'); if (v) v.textContent = rate.toFixed(2).replace(/0$/, ''); };
  }
  const hm = $('#hideMean');
  if (hm) hm.onchange = (e) => document.body.classList.toggle('hide', e.target.checked);
  const pg = $('#playGroup');
  if (pg) pg.onclick = () => playList(dayWords().map((x) => x.w));
  const sd = $('#startDate');
  if (sd) sd.onchange = async (e) => { curState().start = e.target.value || todayStr(); await save(); renderAll(); };
  document.querySelectorAll('#pace button').forEach((b) => {
    b.onclick = async () => { curState().pace = Number(b.dataset.p); await save(); renderAll(); };
  });
  const bind = (id, fn) => { const n = $(id); if (n) n.onclick = fn; };
  bind('#exportCsv', exportCsv);
  bind('#exportAnki', exportAnki);
  bind('#exportAll', () => { download('多词库-进度.json', JSON.stringify(STATE, null, 2), 'application/json'); toast('已导出进度'); });
  const warn = $('#storageWarn');
  if (warn && !S.hasChrome && !storageOK()) warn.hidden = false;
  bind('#importAll', () => { const f = $('#importFile'); if (f) f.click(); });
  const impFile = $('#importFile');
  if (impFile) impFile.onchange = (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const fr = new FileReader();
    fr.onload = async () => {
      try {
        const obj = JSON.parse(String(fr.result));
        if (!obj || !obj.boards) throw new Error('不是有效的进度文件');
        STATE = obj;
        await save(); await refresh(); toast('进度已导入');
      } catch (err) { toast('导入失败：' + err.message); }
    };
    fr.readAsText(file, 'utf-8');
  };
  bind('#reset', async () => {
    if (!confirm('清空当前词库的学习进度？')) return;
    STATE.boards[STATE.active] = { start: todayStr(), pace: curState().pace, words: {}, days: {}, spell: {} };
    await save(); renderAll(); toast('已重置');
  });
  bind('#listToggle', () => { listCollapsed = !listCollapsed; renderBook(); });
  bind('#trAll', () => { artTrAll = !artTrAll; renderArticle(); toast(artTrAll ? '已显示全部翻译' : '已遮蔽翻译'); });
  bind('#articleSpeak', () => { const a = pickArticle(); if (a) speak(a.paras.map((p) => p.en).join(' ')); });
  bind('#reshuffle', () => { shuffleSeed++; shuffleOrder = shuffled(); shuffleIdx = 0; shuffleReveal = false; renderShuffle(); });
  bind('#wpClose', closePop);
  bind('#wpAdd', () => {
    const w = $('#wordPop').dataset.w;
    if (!w) return;
    setStatus(w, 2); toast('已加入生词本'); closePop(); renderStats(); renderBook();
  });
  bind('#wpSay', () => { const w = $('#wordPop').dataset.w; if (w) speak(w); });
  bind('#bookReplay', () => { bookPhase = 'flash'; bookIdx = 0; bookMsg = null; renderBookStudy(); });
  document.querySelectorAll('nav.tabs button').forEach((b) => { b.onclick = () => switchTab(b.dataset.tab); });

  await refresh();
}

/* ---------- 真实文章阅读 ---------- */
let ARTICLES = [];
let artTrAll = false;
let WORDMAP = new Map();

function boardArticles() {
  const list = ARTICLES.filter((a) => (a.levels || []).includes(STATE.active));
  return list.length ? list : ARTICLES;
}
function pickArticle() {
  const list = boardArticles();
  if (!list.length) return null;
  return list[(dayIndex() - 1) % list.length];
}
function buildWordMap() {
  const m = new Map();
  DATA.words.forEach((w) => m.set(w.w.toLowerCase(), w));
  return m;
}
function highlightWords(text) {
  return text.replace(/[A-Za-z][A-Za-z'\-]*/g, (tok) => {
    const w = WORDMAP.get(tok.toLowerCase());
    if (!w) return tok;
    return `<b class="aw" data-w="${w.w}">${tok}</b>`;
  });
}
function renderArticle() {
  const box = $('#article');
  if (!box) return;
  const art = pickArticle();
  if (!art) { box.innerHTML = '<div class="empty">这个词库暂无文章。</div>'; return; }
  WORDMAP = buildWordMap();
  const meta = $('#articleMeta');
  if (meta) {
    const n = art.paras.reduce((a, p) => a + p.en.split(/\s+/).length, 0);
    meta.textContent = `${art.tag} · 约 ${n} 词 · 第 ${(dayIndex() - 1) % boardArticles().length + 1} / ${boardArticles().length} 篇`;
  }
  let html = `<h2>${art.title}</h2><div class="artTag">${art.tag}</div>`;
  art.paras.forEach((p, i) => {
    html += `<div class="para"><p class="en">${highlightWords(p.en)}</p>` +
      `<p class="zh"${artTrAll ? '' : ' hidden'}>${p.zh}</p>` +
      `<button class="trBtn ghost">${artTrAll ? '隐藏翻译' : '翻译'}</button></div>`;
  });
  box.innerHTML = html;
  box.classList.toggle('trAll', artTrAll);
  box.querySelectorAll('.aw').forEach((b) => { b.onclick = () => openPop(b.dataset.w); });
  box.querySelectorAll('.trBtn').forEach((btn) => {
    btn.onclick = () => {
      const zh = btn.parentElement.querySelector('.zh');
      zh.hidden = !zh.hidden;
      btn.textContent = zh.hidden ? '翻译' : '隐藏翻译';
    };
  });
}
function openPop(word) {
  const w = WORDMAP.get(String(word).toLowerCase());
  $('#wpWord').textContent = w ? w.w : word;
  $('#wpIpa').textContent = w && w.p ? `/${w.p}/` : '';
  $('#wpMean').textContent = w ? w.m : '（不在当前词库）';
  $('#wordPop').dataset.w = w ? w.w : word;
  $('#wordPop').classList.add('on');
  speak(w ? w.w : word);
}
function closePop() { $('#wordPop').classList.remove('on'); }

/* ---------- 乱序 ---------- */
let shuffleOrder = [];
let shuffleSeed = 0;
let shuffleIdx = 0;
let shuffleReveal = false;
let shuffleDay = 0;

function shuffled() {
  const arr = dayWords().slice();
  let s = (dayIndex() * 7919 + shuffleSeed * 104729) % 2147483647;
  const rnd = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    const t = arr[i]; arr[i] = arr[j]; arr[j] = t;
  }
  return arr;
}
function renderShuffle() {
  const box = $('#shuffleCard');
  if (!box) return;
  const words = dayWords();
  if (shuffleDay !== dayIndex() || shuffleOrder.length !== words.length) {
    shuffleOrder = shuffled(); shuffleIdx = 0; shuffleReveal = false; shuffleDay = dayIndex();
  }
  if (!shuffleOrder.length) { box.innerHTML = '<div class="empty">今天没有词。</div>'; return; }
  const item = shuffleOrder[shuffleIdx % shuffleOrder.length];
  const meta = $('#shuffleMeta');
  if (meta) meta.textContent = `第 ${shuffleIdx % shuffleOrder.length + 1} / ${shuffleOrder.length} 个（不按顺序）`;
  box.innerHTML = '';
  const card = el('div', 'card');
  card.appendChild(el('div', 'big', item.w));
  card.appendChild(el('div', 'ipa', item.p ? `/${item.p}/` : ''));
  card.appendChild(el('div', 'mean', shuffleReveal ? item.m : '（先回想，点“显示释义”）'));
  const acts = el('div', 'acts');
  const b1 = el('button', 'ghost', shuffleReveal ? '🔊 再听一次' : '显示释义');
  b1.onclick = () => { if (shuffleReveal) return speak(item.w); shuffleReveal = true; renderShuffle(); };
  const b2 = el('button', 'ghost', '✗ 不会');
  b2.onclick = () => { setStatus(item.w, 2); shuffleReveal = false; shuffleIdx++; renderShuffle(); renderStats(); };
  const b3 = el('button', 'pri', '✓ 认识');
  b3.onclick = () => {
    setStatus(item.w, 1); shuffleReveal = false; shuffleIdx++;
    if (shuffleIdx >= shuffleOrder.length) { shuffleIdx = 0; shuffleOrder = shuffled(); toast('一轮过完，重新洗牌'); }
    renderShuffle(); renderStats();
  };
  acts.append(b1, b2, b3);
  card.appendChild(acts);
  box.appendChild(card);
}

boot().catch((e) => {
  document.body.insertAdjacentHTML('beforeend', `<div style="padding:20px;color:#ff6b6b">加载失败：${e.message}</div>`);
});
